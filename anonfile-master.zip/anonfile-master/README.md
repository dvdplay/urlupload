# AnonFile Upload Telegram Bot

## Setup
1 - Enter Your Bot Token Got From [@Botfather](https://t.me/botfather) In TOKEN Variable
2 - Run Main.py

### Developer
Coded By [@TheDarkw3b](https://t.me/TheDarkW3b) :-)
